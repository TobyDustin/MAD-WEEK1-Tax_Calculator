package com.example.tobydustin.testapplication;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        TextView text = (TextView) findViewById(R.id.vert);
//        EditText edit = (EditText)findViewById(R.id.ed);
//

    }
    public void addVAT(View view) {
        TextView text = (TextView) findViewById(R.id.vert);
        EditText edit = (EditText) findViewById(R.id.ed);
        double perc = Integer.parseInt(edit.getText().toString())/100;
        int amount = Integer.parseInt(edit.getText().toString());
        String newAmount = Integer.toString((int) (amount + (amount * 0.2)));
        text.setText((newAmount));
    }
    public void minusVAT(View view){

        TextView text = (TextView) findViewById(R.id.vert);
        EditText edit  = (EditText) findViewById(R.id.ed);
        double perc = Integer.parseInt(edit.getText().toString())/100;
        int amount = Integer.parseInt(edit.getText().toString());

        String newAmount = Integer.toString((int) (amount - (amount * 0.2)));
        text.setText((newAmount));
    }



}
